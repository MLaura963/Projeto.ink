if ("serviceWork" in navigator) {
    console.log("oi")
window.addEventListener("load", function (){
    navigator.serviceWorker.register("projeto ink/serviceW.js").then(
        function(registration) {
            console.log(
                "ServiceWork ok <3", registration.scope
            );
        },
        function (error){
            console.log('volta que deu merda', error)

        }
        );

               
});

}
